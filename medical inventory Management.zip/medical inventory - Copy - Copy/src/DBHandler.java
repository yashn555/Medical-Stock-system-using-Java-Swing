import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DBHandler {
    private static final String URL = "jdbc:mysql://localhost:3306/pharmacy";
    private static final String USERNAME = "root";
    private static final String PASSWORD = " ";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }

    public static boolean addStock(String itemName, String itemPrice, String selectedCategory, int quantity, String selectedSupplier, String paymentMode) {
        try {
            Connection conn = getConnection();
            String query = "INSERT INTO stock (itemName, itemprice, category, quantity, supplier, paymentmode) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, itemName);
            statement.setString(2, itemPrice);
            statement.setString(3, selectedCategory);
            statement.setInt(4, quantity);
            statement.setString(5, selectedSupplier);
            statement.setString(6, paymentMode);

            int rowsInserted = statement.executeUpdate();
            conn.close();

            return rowsInserted > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
}
